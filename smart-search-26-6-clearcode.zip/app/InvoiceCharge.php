<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class InvoiceCharge extends Model
{
    protected $table = 'charges';

}
