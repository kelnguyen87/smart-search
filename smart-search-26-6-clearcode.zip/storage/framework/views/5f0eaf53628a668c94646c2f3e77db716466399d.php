<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="content-header">
            <div class="row align-items-center">
                <div class="col-md-7">
                    <h2>Price Plans</h2>
                </div>
            </div>
        </div>
        <div class="box box-list">
            <div class="box-body">
                <div id="list-offer">
                    <div class="table-responsive">
                        <table class="table table-bordered table-list-offers table-hover dataTable">
                            <thead>
                            <tr role="row">
                                <th>#</th>
                                <th>Name</th>
                                <th>View limit</th>
                                <th>Price</th>
                            </tr>
                            </thead>
                            <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php echo e($plan->id); ?>

                                    </td>
                                    <td>
                                        <?php echo e($plan->name); ?>

                                    </td>
                                    <td>
                                        <?php if($plan->capped_amount >0): ?>
                                            <?php echo e((int)$plan -> capped_amount); ?>

                                        <?php else: ?>
                                            Unlimited
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        $ <?php echo e($plan->price); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>