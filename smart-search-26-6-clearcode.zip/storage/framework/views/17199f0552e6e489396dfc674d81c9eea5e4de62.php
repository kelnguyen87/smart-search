Hello Shopify

<?php echo e(dd($data)); ?>