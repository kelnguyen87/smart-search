<div class="table-responsive">
    <table class="table table-bordered table-list-offers table-hover dataTable">
        <thead>
        <tr role="row">
            <th class="ls-active">Active</th>
            <th class="ls-name">Name</th>
            <th class="ls-type">Type</th>
            <th class="ls-location">Location</th>
            <th class="ls-date">Date Created</th>
            <th class="ls-report">Report</th>
            <th class="ls-action">Delete</th>
        </tr>
        </thead>
        <?php $__currentLoopData = $listOffer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <label class="switch-checkbox">
                        <input type="checkbox" class="change-active-status" offer-id="<?php echo e($value->id); ?>" <?php if($value->active): ?> checked <?php endif; ?> data-toggle="toggle">
                        <span class="slider round"></span>
                    </label>
                </td>
                <td class="ls-name">
                    <span> <a href="<?php echo e(url('/').'/offer/edit/'.$value->id); ?>"><?php echo e($value->name); ?></a></span>
                </td>
                <td class="ls-type">
                    <?php echo e($value->type); ?>

                </td>
                <td class="ls-location">
                    <?php echo e($value->trigger_place); ?>

                </td>
                <td>
                    <?php echo e($value->created_at); ?>

                </td>
                <td>
                    <a href="<?php echo e(url('/').'/report/offer/'.$value->id); ?>"><i class="fa fa-bar-chart" aria-hidden="true"></i></a>
                </td>
                <td>
                    <button class="btn btn-default button-delete-offer" offer-id="<?php echo e($value->id); ?>"><i class="fa fa-trash" aria-hidden="true"></i></button>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
<?php echo $listOffer->links(); ?>

