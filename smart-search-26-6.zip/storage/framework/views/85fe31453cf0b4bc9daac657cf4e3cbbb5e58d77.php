<table class="table table-bordered table-list-offers table-hover dataTable">
    <thead>
    <tr role="row">
        <th class="ls-name">Name</th>
        <th class="ls-type">Type</th>
        <th class="ls-percent-add">Views</th>
        <th class="ls-added-amount">Added to cart</th>
        <th class="ls-added">Added to cart %</th>
        <th class="ls-added-amount">Purchase</th>
        <th class="ls-added-amount">Purchase %</th>
        <th class="ls-added-amount">Purchase Amount</th>
    </tr>
    </thead>
    <?php $__currentLoopData = $offerList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="ls-name">
                <span> <a href="/offer/edit/<?php echo e($value->id); ?>"><?php echo e($value->name); ?></a></span>
            </td>
            <td>
                <?php echo e($value->type); ?>

            </td>
            <td>
                <?php echo e($value->total); ?>

            </td>
            <td>
                <?php if(isset($append_data[$value->id])): ?>
                    <?php echo e($append_data[$value->id]['added']); ?>

                <?php else: ?>
                    0
                <?php endif; ?>
            </td>
            <td>
                <?php if(isset($append_data[$value->id]) && $value->total != 0): ?>
                    <?php echo e(round(($append_data[$value->id]['added'] /$value->total)*100,2)); ?> %
                <?php else: ?>
                    0%
                <?php endif; ?>
            </td>
            <td>
                <?php if(isset($append_data[$value->id]) && isset($append_data[$value->id]['purchase'])): ?>
                    <?php echo e($append_data[$value->id]['purchase']); ?>

                <?php else: ?>
                    0
                <?php endif; ?>
            </td>
            <td>
                <?php if(isset($append_data[$value->id]) && isset($append_data[$value->id]['purchase']) && isset($append_data[$value->id]['added'])): ?>
                    <?php echo e(round($append_data[$value->id]['purchase']/$append_data[$value->id]['added']*100,2)); ?> %
                <?php else: ?>
                    0
                <?php endif; ?>
            </td>
            <td>
                <?php if(isset($append_data[$value->id]) && isset($append_data[$value->id]['purchase'])): ?>
                    <?php echo e($append_data[$value->id]['amount']); ?>

                <?php else: ?>
                    0
                <?php endif; ?>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php echo $offerList->links(); ?>

