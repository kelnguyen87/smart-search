<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="content-header">
            <div class="row align-items-center">
                <div class="col-md-7">
                    <h2>View by months</h2>
                </div>
            </div>
        </div>
        <div class="box box-list">
            <div class="box-body">
                <div id="list-offer">
                    <div class="table-responsive">
                        <table class="table table-bordered table-list-offers table-hover dataTable">
                            <thead>
                            <tr role="row">
                                <th>Month</th>
                                <th>Views</th>
                                <th>Plan</th>
                                <th>Price</th>
                                <th>Status</th>
                            </tr>
                            </thead>
                            <tr>
                                <td>
                                    <b><?php echo e(sprintf("%02d", $view_this_month['month'])); ?> / <?php echo e($view_this_month['year']); ?> (Current month)</b>
                                </td>
                                <td>
                                    <b><?php echo e((int)$view_this_month['view']); ?></b>
                                </td>
                                <td>
                                    <?php echo e($view_this_month['name']); ?>

                                </td>
                                <td>
                                    <b>$ <?php echo e($view_this_month['price']); ?></b>
                                </td>
                                <td>
                                    N/A
                                </td>
                            </tr>
                            <?php $__currentLoopData = $view_by_months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php
                                            $date = $value['activated_on'];
                                            $month = date("m",strtotime($date));
                                            $year = date("Y",strtotime($date));
                                        ?>
                                        <?php echo e($month); ?> / <?php echo e($year); ?>

                                    </td>
                                    <td>
                                        <b><?php echo e((int)$value['capped_amount']); ?></b>
                                    </td>
                                    <td>
                                        <?php echo e($value['name']); ?>

                                    </td>
                                    <td>
                                        <b>$ <?php echo e($value['price']); ?></b>
                                    </td>
                                    <td>
                                        <?php if($value['status'] == 0): ?>
                                            Unpaid
                                        <?php else: ?>
                                            Paid
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>