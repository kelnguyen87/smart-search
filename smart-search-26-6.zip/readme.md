##Used
- Laravel 5.7 - doc: https://laravel.com/docs/5.7
- AdminLTE 2.4 - homepage: https://adminlte.io/
- ohmybrew laravel-shopify - Git: https://github.com/ohmybrew/laravel-shopify
##Setup
- Composer
- Npm
- Migrate data
# smart-search
